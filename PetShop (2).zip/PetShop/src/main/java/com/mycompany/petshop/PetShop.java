package com.mycompany.petshop;
import java.util.Scanner;

public class PetShop  {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        int opt = 0;
        
        do{
            
            System.out.println("--Mascotas--");
            System.out.println("1) Agregar perro");
            System.out.println("2) Agregar gato");
            System.out.println("3) Agregar conejo");
            System.out.println("4) Salir");

            opt = input.nextInt();

                if(opt == 1){
                
                System.out.println("Ingrese el id del perro: ");
                String idPerro = input.next();
                
                System.out.println("Ingrese el alimento del perro: ");
                String alimento = input.next();
                
                System.out.println("Ingrese la cantidad de salidas diarias: ");
                int salidas = input.nextInt();

                Perro perro = new Perro(idPerro, alimento, salidas);
                    perro.ImprimirRecepcion();

            } else if(opt== 2){
                System.out.println("Ingrese la id del Gato");
                String idGato = input.next();

                System.out.println("Ingrese la alimento del Gato: ");
                String alimento = input.next();

                Gato gato = new Gato(idGato, alimento);

                    System.out.println("Gato agregado con exito");

                    gato.ImprimirRecepcion();


            } else if (opt==3) {
                    System.out.println("Ingrese el id del Conejo");
                    String idConejo = input.next();

                    System.out.println("Comparte jaula? True/False:");
                    boolean comparteJaula = input.nextBoolean();


                    System.out.println("Conejo ingresado con exito: ");

                    Conejo conejo = new Conejo(idConejo,"Zanahoria",comparteJaula);
                    conejo.ImprimirRecepcion();
                }else if(opt==4){
                System.out.println("Saliste con exito");
                }else {

                    System.out.println("Opción inválida. Ingrese otra opcion.");
                }


        } while (opt != 4);


        input.close();
    }
}

