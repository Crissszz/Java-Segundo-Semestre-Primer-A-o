package empleado;

public class Empleado {
    // 1. Los campos (variables de instancia) se definen aquí,
    // directamente dentro de la clase.
    protected String idEmpleado;
    protected String nombre;
    protected double sueldoBase;

    // Constructor
    public Empleado(String idEmpleado, String nombre, double sueldoBase) {
        this.idEmpleado = idEmpleado;
        this.nombre = nombre;
        this.sueldoBase = sueldoBase;
    }
   

    // Método main (opcional, solo para ejecutar y probar la clase)
    public static void main(String[] args) {
        // El método main se usa para crear y usar objetos.
        // Ejemplo de uso:
        // Empleado miEmpleado = new Empleado("A001", "Ana Gómez", 65000.0);
        // System.out.println("El sueldo de " + miEmpleado.getNombre() + " es: " + miEmpleado.getSueldoBase());
    }

    // Métodos Getter
    public String getIdEmpleado() {
        return idEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public double getSueldoBase() {
        return sueldoBase;
    }
}
    

