
package rrhm;
import java.util.ArrayList;
import java.util.List;


public class Departamento {
private String idDepartamento;
private String nombre;
private List <Empleado> empleados;

    public Departamento(String idDepartamento, String nombre, List<Empleado> empleados) {
        this.idDepartamento = idDepartamento;
        this.nombre = nombre;
        this.empleados = empleados;
    }

public void agregarEmpleado(Empleado emple){
    empleados.add (emple);
    
}
public double calcularCostoTotalSalarios(){
double total= 0;

for(Empleado emp : empleados){ 
total += emp.calcularSalario();
}

return total;

}
}
