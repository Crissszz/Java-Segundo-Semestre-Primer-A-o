
package rrhm;


public interface BonusCalculable {

public double bonusCalculable();
}

