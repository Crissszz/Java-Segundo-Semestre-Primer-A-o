package com.mycompany.petshop;


public class Conejo extends Mascota{
    private boolean comparteJaula;

    public Conejo(String idMascota, String alimento, boolean comparteJaula) {
        super(idMascota, alimento);
        this.comparteJaula = comparteJaula;
    }

    @Override
    public double calcularValorFinal() {
        
        double valorFinal = VALOR_BASE;
        
        if(comparteJaula = true){
            
            valorFinal = valorFinal * 1.07;
            
        }
        
        return valorFinal;
        
    }
    @Override
    public void ImprimirRecepcion() {
        System.out.println("idConejo: " + idMascota);
        System.out.println("Salario del alimento: " + alimento);
        System.out.println("Costo mas conejos en jaula: " + comparteJaula);
        System.out.println("Costo total servicio: $" + calcularValorFinal());
}
}
