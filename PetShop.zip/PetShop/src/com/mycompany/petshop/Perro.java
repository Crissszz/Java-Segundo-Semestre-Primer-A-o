
package com.mycompany.petshop;

public class Perro extends Mascota{
    private int salidasDiarias;

    public Perro(String idMascota, String alimento, int salidasDiarias) {
        super(idMascota, alimento);
        this.salidasDiarias = salidasDiarias;
    }

    @Override
    public double calcularValorFinal() {
        double valorFinal = VALOR_BASE;
        
        if(salidasDiarias > 3){
            valorFinal = valorFinal * 1.07;
        }
        
        return valorFinal;
        
    }
    @Override
    public void ImprimirRecepcion() {
        System.out.println("idPerruno: " + idMascota);
        System.out.println("Salario del alimento: " + alimento);
        System.out.println("Salario del perro: " + salidasDiarias);
        System.out.println("Costo total servicio: $" + calcularValorFinal());
}
}