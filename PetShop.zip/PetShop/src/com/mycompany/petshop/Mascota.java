package com.mycompany.petshop;

import java.util.ArrayList;
import java.util.List;

public abstract class Mascota implements iServicio{
    protected String idMascota;
    protected String alimento;
    protected List<Mascota> mascota;

    public Mascota(String idMascota, String alimento) {
        this.idMascota = idMascota;
        this.alimento = alimento;
        this.mascota = new ArrayList<>();
    }

    public String getIdMascota() {
        return idMascota;
    }
    
    public void agregarMascota(Mascota masc){
        mascota.add(masc);
    }
}
