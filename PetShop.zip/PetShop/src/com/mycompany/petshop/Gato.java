
package com.mycompany.petshop;


public class Gato extends Mascota{
    public Gato(String idMascota, String alimento) {
        super(idMascota, alimento);
    }

    @Override
    public double calcularValorFinal() {

        return VALOR_BASE * 1.05;

    }

    @Override
    public void ImprimirRecepcion() {
        System.out.println("Salario del alimento: " + alimento);
        System.out.println("idGatuno: " + idMascota);
        System.out.println("Calculo final gasto Gato :" + calcularValorFinal());

    }
}
