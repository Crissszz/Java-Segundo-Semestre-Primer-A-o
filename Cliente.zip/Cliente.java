
package shop;
import java.util.ArrayList;
import java.util.List;

public class Cliente {
private String id;
private String nombre;
private List<Pedido> pedidosRealizados;

    public Cliente(String id, String nombre, List<Pedido> pedidosRealizados) {
        this.id = id;
        this.nombre = nombre;
        this.pedidosRealizados = new Arraylist<>();
    }

   
  public void realizarPedido (Pedido pedido) {
      
      double total = pedidos.getTotal();
      pedidosRealizados.add(pedido);
      System.out.println("Pedido realizado con exito, el precio es : $"+total);
      
  }

}
